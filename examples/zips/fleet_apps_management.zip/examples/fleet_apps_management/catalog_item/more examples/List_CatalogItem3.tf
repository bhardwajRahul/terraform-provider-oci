
variable "tenancy_ocid" {
  default = "ocid1.tenancy.oc1.."
}

data "oci_fleet_apps_management_catalog_items" "test_catalog_items" {
  catalog_listing_version_criteria = "LIST_ALL_VERSIONS"
  compartment_id                   = "${var.compartment_id}"
  config_source_type               = "PAR_CATALOG_SOURCE"
  display_name                     = "displayName2"
  filter {
    name   = "id"
    values = ["${oci_fleet_apps_management_catalog_item.test_catalog_item.id}"]
  }
  package_type             = "TF_PACKAGE"
  should_list_public_items = "false"
  state                    = "ACTIVE"
}
variable "compartment_id" { default = "ocid1.compartment.oc1.." }

resource "oci_fleet_apps_management_catalog_item" "test_catalog_item" {
  catalog_source_payload {
    access_uri         = ""
    bucket             = "test-catalog-bucket"
    config_source_type = "PAR_CATALOG_SOURCE"
    namespace          = "namespace"
    object             = "ObjectStorageCatalog.zip"
    time_expires       = "2029-12-31T00:00:00Z"
    working_directory  = "workingDirectory"
  }
  compartment_id     = "${var.compartment_id}"
  config_source_type = "PAR_CATALOG_SOURCE"
  defined_tags       = "${map("Oracle-Tags.CreatedBy", "updatedValue")}"
  description        = "description2"
  display_name       = "displayName2"
  freeform_tags = {
    "Department" = "Accounting"
  }
  package_type        = "TF_PACKAGE"
  short_description   = "shortDescription2"
  time_released       = "2025-10-27T00:00:00.000Z"
  version_description = "V2"
}
