// Copyright (c) 2017, 2024, Oracle and/or its affiliates. All rights reserved.
// Licensed under the Mozilla Public License v2.0

variable "tenancy_ocid" {}
variable "user_ocid" {}
variable "fingerprint" {}
variable "private_key_path" {}
variable "region" {}
variable "data_safe_target_ocid" {}
variable "data_safe_masking_policy_id" {}

provider "oci" {
  tenancy_ocid     = var.tenancy_ocid
  user_ocid        = var.user_ocid
  fingerprint      = var.fingerprint
  private_key_path = var.private_key_path
  region           = var.region
}


resource "oci_data_safe_masking_policy_health_report_management" "test_health_report" {
  #Required
  target_id = var.data_safe_target_ocid
  masking_policy_id = var.data_safe_masking_policy_id
}